# **OOP Project : Travel booking Project using JDBC**  

  

_This is a Project to Help in booking Airplane as well as hotel tickets. Various Flight details such as flight number, Flight timings, Date of Flight etc., as well as Hotel Details Like City name, Number of rooms, Hotel name are stored in the Database. Using these databases with the help of Java programs, a customer can ensure his/her flight as well as hotels Tickets booking with ease._

  

Program Flow : 

1] The user is asked For Authentication detais. 

  

1a. If the Authentication details matches with that in the database, The user is given further acccess to continue with the tickets booking. 

1b. If the user iD does not match in the Database, The user is asked if he/she wants to register within the portal. 

1c. If the user ID matches with the user ID in the Database, but the password does not match, then an error is thrown. 

If registerd successfully, then the user is asked to log in again. 

  

2] Once the user has successfully logged in, He/she is asked by the program weather the customer wants to book Airplane tickets or Hotel tickets. 

  

3] Based on the choice, the user gets The Table of flights schedule, or hotels available based on the trip details enterd by them. The user is then asked if he / she wants to continue with the booking of selected flight or hotel. 

  

4] The user is then taken to the booking section, wherein he/she can confirm the ticket booking. Finally, The user gets the process confirmation and the ticket is booked.